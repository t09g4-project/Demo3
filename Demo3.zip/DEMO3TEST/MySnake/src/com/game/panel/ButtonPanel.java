package com.game.panel;

import com.game.listener.ButtonListener;

import javax.swing.*;

/**
 * This class creates a panel that will contain two buttons, (1 player, 2 players).
 * This panel will be used at the start of the program to determine if the user wants to play the game
 * with one player or two players.
 */
public class ButtonPanel extends JPanel {
    public ButtonPanel(JFrame jFrame) {
        JButton button1 = new JButton("1 Player");
        JButton button2 = new JButton("2 Players");
        button1.addActionListener(new ButtonListener(jFrame));
        button2.addActionListener(new ButtonListener(jFrame));
        this.add(button1);
        this.add(button2);
    }
}
