package com.game.panel;

import com.game.common.Configure;
import com.game.listener.Player2KeyListener;
import com.game.main.Element;
import com.game.main.Snake;
import com.game.main.SnakeBody;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 */
public class TwoPlayerPanel extends PlayerPanel {
    private volatile Snake snake2;


    public TwoPlayerPanel() {
        super();
    }

    /**
     *
     * @param g
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (!snake2.isAlive())
            dead2(g);
        if (!getSnake().isAlive() && !snake2.isAlive()){
            gameover(g);
        }
    }

    /**
     *
     */
    @Override
    public void initSnake(){
        super.initSnake();
        initSnake2();
    }

    /**
     *
     */
    private void initSnake2() {
        SnakeBody tempSnakeBody = new SnakeBody(Configure.SnakeBody.image2);
        do {
            setRandomPosition(tempSnakeBody);
        } while (isExistElement(tempSnakeBody));
        this.snake2 = new Snake(tempSnakeBody.getX(), tempSnakeBody.getY(), Configure.SnakeBody.image2);
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList<Element> getAllElement() {
        ArrayList<Element> elements = super.getAllElement();
        elements.addAll(snake2.getBodies());
        return elements;
    }

    /**
     *
     * @param g
     */
    @Override
    public void renderScore(Graphics g) {
        super.renderScore(g);
        g.setColor(snake2.getBodyColor());
        g.drawString("Score: " + snake2.getScore(), Configure.Element.ElementWidth * (Configure.Board.XNum + 10),
                Configure.Element.ElementWidth * 3);
    }

    /**
     *
     */
    @Override
    public void run() {
        super.run();
        JPanel thisjpanel = this;
        new Thread(new Runnable() {
            @Override
            public void run() {
                thisjpanel.addKeyListener(new Player2KeyListener(snake2));
                thisjpanel.setFocusable(true);
                thisjpanel.requestFocusInWindow();
                runSnake(snake2);
            }
        }).start();
    }

    /**
     *
     * @param g
     * @param e
     */
    @Override
    void fillRect(Graphics g, Element e) {
        int width = Configure.Element.ElementWidth;
        try {
            BufferedImage img;
            Element head = getSnake().getBodies().getFirst();
            Element head2 = snake2.getBodies().getFirst();
            if ((e.getX() == head.getX() && e.getY() == head.getY()) || (e.getX() == head2.getX() && e.getY() == head2.getY())){
                img = ImageIO.read(new File(Configure.SnakeBody.head));
            } else {
                img = ImageIO.read(new File(e.getImagePath()));
            }
            g.drawImage(img, e.getX() * width, e.getY() * width, width, width, null);
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    /**
     *
     * @param g
     */
    public void dead2(Graphics g) {
        g.setColor(Color.RED);
        g.drawString("Dead!", Configure.Element.ElementWidth * (Configure.Board.XNum + 15),
                Configure.Element.ElementWidth * 3);
    }

    /**
     *
     * @param g
     */
    public void gameover(Graphics g) {
        g.setColor(Color.RED);
        g.drawString("Game Over!", Configure.Element.ElementWidth * (Configure.Board.XNum + 13),
                Configure.Element.ElementWidth * 8);
    }
}
