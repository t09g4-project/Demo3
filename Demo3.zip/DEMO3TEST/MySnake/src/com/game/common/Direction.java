package com.game.common;

/**
 * This class contains the predefined directions to move
 */
public enum Direction {
    UP, DOWN, LEFT, RIGHT;
    // for directions to move
}
