package com.game;

import com.game.main.GameFrame;

/**
 * This class is the main method to run the program 
 */
public class Main {

    public static void main(String[] args) {
        new GameFrame();
    }
}
