package com.game.listener;

import com.game.panel.PlayerPanel;
import com.game.panel.TwoPlayerPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * This class is responsible for listening to the player 1 and player 2 buttons.
 */
public class ButtonListener implements ActionListener {
    private JFrame jFrame;

    // not sure if correct.
    /**
     * constructor that accepts a JFrame object.
     * @param jFrame (Type JFrame)
     */
    public ButtonListener(JFrame jFrame) {
        this.jFrame = jFrame;
    }

    /**
     * Method that will preform an action depending on which button was pressed.
     * If 1 Player was pressed, it will change the panel to PlayerPanel.
     * Otherwise it will change the panel to TwoPlayerPanel
     * @param e (Type ActionEvent, this is the event - what was pressed)
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        removeButton(e);
        if (e.getActionCommand().equals("1 Player"))
            changePanel(new PlayerPanel());
        else
            changePanel(new TwoPlayerPanel());
    }

    /**
     *
     * @param e
     */
    private void removeButton(ActionEvent e) {
        JButton clickButton = (JButton)e.getSource();
        Container parent = clickButton.getParent();
        parent.removeAll();
        parent.repaint();
    }

    /**
     * This method changes the Jpanel.
     * @param jPanel (Object JPanel - It is the new JPanel you want to switch to)
     */
    private void changePanel(JPanel jPanel) {
        jFrame.setContentPane(jPanel);
        jFrame.revalidate();
        jFrame.repaint();
    }
}
