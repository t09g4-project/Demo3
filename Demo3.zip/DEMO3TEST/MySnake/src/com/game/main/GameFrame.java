package com.game.main;

import com.game.common.Configure;
import com.game.panel.ButtonPanel;

import javax.swing.*;

/**
 * This class is responsible for the main frame of the game.
 */
public class GameFrame extends JFrame {

    /**
     * Constructor that will set up the title of the window, add the Button panels (the player 1, player 2 option), set
     * up the board.
     */
    public GameFrame() {
        this.setTitle("Snake Game");
        JPanel panel = new ButtonPanel(this);
        this.setContentPane(panel);
        this.setVisible(true);
        this.setSize(Configure.Element.ElementWidth * (Configure.Board.XNum + 20),
                Configure.Element.ElementWidth * (Configure.Board.YNum + 2));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}
