package com.game.main;

import com.game.common.Configure;

/**
 * This class is responsible for setting the elements of the Food object.
 */
public class Food extends Element {


    public Food() {
        this.setColor(Configure.Food.color);
        this.setScore(Configure.Food.score);
        this.setEatable(true);
        this.setImagePath(Configure.Food.image);
        // Food can be eat
    }
}
