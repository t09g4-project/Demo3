package test;

import com.game.common.Configure;
import com.game.common.Direction;
import com.game.main.Food;
import com.game.main.Bonus;
import com.game.main.Poison;
import com.game.main.Snake;

import java.awt.*;

import static org.junit.Assert.*;

public class SnakeTest {

    // Snake eat food shoud grow two body
    @org.junit.Test
    public void eatFood() {
        Snake snake = new Snake(0, 0, Configure.ImageRootPath);
        Food food = new Food();
        snake.eatElement(food);
        assertEquals(2, snake.getBodies().size());
    }

    @org.junit.Test
    public void eatPosion() {
        Snake snake = new Snake(0, 0, Configure.ImageRootPath);
        Poison poison = new Poison();
        snake.eatElement(poison);
        assertEquals(0, snake.getBodies().size());
    }

    @org.junit.Test
    public void nextY() {
        Snake snake = new Snake(0, 0, Configure.ImageRootPath);
        snake.setDirection(Direction.DOWN);
        assertEquals(1, snake.nextY());
    }
    
    @org.junit.Test
    public void eatBonus() {
    	Snake snake = new Snake(0 , 0, Configure.ImageRootPath);
    	Bonus bonus = new Bonus();
    	snake.eatElement(bonus);
    	assertEquals(3, snake.getBodies().size());
    }

    @org.junit.Test
    public void moveNormally() {
        Snake snake = new Snake(0, 0, Configure.ImageRootPath);
        snake.setDirection(Direction.DOWN);
        snake.eatElement(null);
        assertEquals(1, snake.getBodies().size());
        assertEquals(1, snake.getBodies().getFirst().getY());
    }
}
