import java.awt.*;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Random;


public class Snake {
   static final int WIDTH = 40, HEIGHT = 10;
   static char[][] map = new char[HEIGHT][WIDTH];
   //make a char array for the game map
   public static void main(String[] args) {
      Snake snake = new Snake();
      snake.iBackground();
      Snakebody snakebody = new Snakebody();
      Bomber bomber = new Bomber();
      Food food = new Food();
      food.initFood(3);
      snakebody.initSnake();
      bomber.initBomber(10);
      snake.putSnakeInMap(snakebody);
      snake.putBomberInMap(bomber);
      snake.putFoodInMap(food);
      snake.show();

      Scanner scanner = new Scanner(System.in);
      int move;
      while (true) {
         System.out.println("Use AWSD to move the snake, Press Q to quit the game");
         String choice = scanner.next();
         switch (choice.toLowerCase()) {
            case "a":
               move = 2;
               break;
            case "s":
               move = 1;
               break;
            case "w":
               move = 3;
               break;
            case "d":
               move = 0;
               break;
            case "q":
               int points=snakebody.snakePoints.size();
               snake.putGameOverInMap(points);
            default:
               System.out.println("Input Error, Please try again");
               continue;
         }
         //set a loop for snake to move by using AWSD.
         if (snakebody.move(move) == -1) {
            System.out.println("YOU HIT THE WALL!");
            snake.putGameOverInMap(snakebody.snakePoints.size());
            snake.show();
            break;
            //when snake collide with body or the border of the game, GameOver will be put in the map.
         }
         int detectB = bomber.detectBomb(snakebody.snakePoints.getFirst());
         if (detectB == -1){
           System.out.println("YOU ATE A BOMBER!");
           snake.putGameOverInMap(snakebody.snakePoints.size());
           snake.show();
           break;
         }
         int detectF = food.detectFood(snakebody.snakePoints.getFirst());
         if (detectF == -1){
           snakebody.snakePoints.addLast(new Point(snakebody.snakePoints.getLast().x - 1, snakebody.snakePoints.getLast().y));
           snake.putBomberInMap(bomber);
           snake.putSnakeInMap(snakebody);
           food.initFood(3);
           snake.putFoodInMap(food);
         }
         snake.iBackground();
         snake.putSnakeInMap(snakebody);
         snake.putFoodInMap(food);
         snake.putBomberInMap(bomber);
         snake.show();
         //put snake into the game
      }
   }
   // build a 2D array to represent the background of the map
   private void iBackground() {
      for (int i = 0; i < HEIGHT; i++) {
         for (int j = 0; j < WIDTH; j++) {
            this.map[i][j] = (j == 0 || (j == WIDTH - 1) || i == 0 || (i == HEIGHT - 1)) ? '*' : ' ';
            // if the boolean return true, this.map[i][j] will equal to "*", which represent the wall in the game
            // if the boolean return false, this.map[i][j] will equal to " ", wich represent the space area in the game
         }
      }
   }
   // print out the map according to the 2D array
   public void show() {
      int height = map.length;
      int width = map[0].length;
      for (int i = 0; i < height; i++) {
         for (int j = 0; j < width; j++) {
            System.out.print(map[i][j]);
         }
         System.out.println();
      }
   }
   public void putBomberInMap(Bomber bomber){
     Point a;
     for (int i = 0; i < bomber.bomberGroup.size(); i++){
       a = bomber.bomberGroup.get(i);
       if(a.y > 0 && a.y < HEIGHT - 1 && a.x > 0 && a.x < WIDTH - 1) {
          map[a.y][a.x] = Bomber.bomberPoint;
        }
      }
    }
    public void putFoodInMap(Food food){
      Point a;
      for (int i = 0; i < food.foodGroup.size(); i++){
        a = food.foodGroup.get(i);
        if(a.y > 0 && a.y < HEIGHT - 1 && a.x > 0 && a.x < WIDTH - 1) {
           map[a.y][a.x] = food.foodPoint;
         }
       }
     }
   // use the element of snakeLine to replace the element of map array
   void putSnakeInMap(Snakebody snakebody) {
      Point p;
      map[Snakebody.food.y][Snakebody.food.x] = Snakebody.worm;
      for (int i = 0; i < snakebody.snakePoints.size(); i++) {
         p = snakebody.snakePoints.get(i);
         if (p.y > 0 && p.y < HEIGHT - 1 && p.x > 0 && p.x < WIDTH - 1) {
            map[p.y][p.x] = (i == 0) ? snakebody.head : snakebody.body;
         } else {
            putGameOverInMap(snakebody.snakePoints.size());
         }
      }
   }
   // print Gameover in map if the snake die
   //the original length of the snake is 3, so the mark = snake length - 3
   void putGameOverInMap(int points) {
      char[] gameOver = ("GameOver Score:"+(points-3)).toCharArray();
      for (int i = 0; i < gameOver.length; i++) {
         map[HEIGHT / 2 - 1][i + (WIDTH - gameOver.length) / 2] = gameOver[i];
      }
      show();
      System.exit(1);
   }
}
