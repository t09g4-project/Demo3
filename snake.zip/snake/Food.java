import java.awt.*;
import java.util.LinkedList;

public class Food extends Snake{
  static char foodPoint = '~';
  private int numOfFood = 3;
  LinkedList<Point> foodGroup = new LinkedList<>();
  public void initFood(int numOfFood){
    while (this.foodGroup.size()>0){
      foodGroup.remove();
    }
    for (int i = 0; i < this.numOfFood; i++){
      int x=(int)(Math.random()*40);
      int y=(int)(Math.random()*10);
      foodGroup.addLast(new Point(x,y));
    }
  }
  public int detectFood(Point head){
    Point a;
    for (int i = 0; i < this.foodGroup.size(); i++){
      a = this.foodGroup.get(i);
      if(head.y == a.y && head.x == a.x) {
        return -1;
      }
    }
    return 1;
  }
}
