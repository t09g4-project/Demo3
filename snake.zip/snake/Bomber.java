import java.awt.*;
import java.util.LinkedList;

public class Bomber extends Snake{
  static final char bomberPoint = 'X';
  private int numOfBomber = 10;
  LinkedList<Point> bomberGroup = new LinkedList<>();
  public void initBomber(int numOfBomber){
    for (int i = 0; i < this.numOfBomber; i++){
      int x=(int)(Math.random()*40);
      int y=(int)(Math.random()*10);
      bomberGroup.addLast(new Point(x,y));
    }
  }
  public int detectBomb(Point head){
    Point a;
    for (int i = 0; i < this.bomberGroup.size(); i++){
      a = this.bomberGroup.get(i);
      if(head.y == a.y && head.x == a.x) {
        return -1;
      }
    }
    return 1;
  }
}
